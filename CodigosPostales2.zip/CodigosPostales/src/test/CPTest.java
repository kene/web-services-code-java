package test;

import java.util.Collection;
import java.util.Iterator;

import com.example.CodigoPostal;
import com.example.service.CodigoPostalServiceImpl;
import com.example.service.CodigoPostalService;

public class CPTest {

	public static void main(String[] args) {
		CodigoPostalService cpService = new CodigoPostalServiceImpl();
		
		CodigoPostal cp = cpService.consultarCodigoPostalPorCodigo("09980");
		System.out.println("CP: " + cp);
		System.out.println("----------------------------- ");
                
		Collection <CodigoPostal>c = cpService.consultarCodigosPostales();
		for (CodigoPostal tmp : c) {
			System.out.println("Item2 CP: " + tmp);
		}
		
		System.out.println("----------------------------- ");
		Collection <CodigoPostal>c2 = cpService.consultarCodigoPostalPorNombre("insurgentes");
		for (CodigoPostal tmp : c2) {
			System.out.println("Item3 CP: " + tmp);
		}

        }

}
