package com.example.service;

import java.util.Collection;

import com.example.CodigoPostal;
import com.example.dao.CodigoPostalDAO;

public class CodigoPostalServiceImpl implements CodigoPostalService {
	/* Aqui la clase es responsable de buscar su DAO */
	private CodigoPostalDAO codigoPostalDAO = new CodigoPostalDAO();
	
	/* (non-Javadoc)
	 * @see com.example.service.CodigoPostalService#consultarCodigosPostales()
	 */
	@Override
	public Collection<CodigoPostal> consultarCodigosPostales() {
		return codigoPostalDAO.selectAll();
	}
	
	/* (non-Javadoc)
	 * @see com.example.service.CodigoPostalService#consultarCodigoPostal(java.lang.String)
	 */
	@Override
	public CodigoPostal consultarCodigoPostalPorCodigo(String codigo) {
		return codigoPostalDAO.selectCpById(codigo);
	}
        
	@Override
	public  Collection<CodigoPostal> consultarCodigoPostalPorNombre(String codigo) {
		return codigoPostalDAO.selectCpByName(codigo);
	}
	
}
