package com.example;

/**
 * WS Course
 * @author JLIL
 */
public enum Estado {
    CDMX, Mexico, Veracruz, Jalisco;
}
