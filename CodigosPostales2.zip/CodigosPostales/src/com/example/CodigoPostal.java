package com.example;

import java.io.Serializable;

public class CodigoPostal implements Serializable {

    private Integer id;
    private String codigo;
    private String colonia;
    private String delegacion;
    private Estado estado;

    public CodigoPostal() {
    }

    public CodigoPostal(Integer id, String codigo, String colonia, String delegacion, Estado estado) {
        this.codigo = codigo;
        this.colonia = colonia;
        this.id = id;
        this.delegacion = delegacion;
        this.estado = estado;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDelegacion() {
        return delegacion;
    }

    public void setDelegacion(String delegacion) {
        this.delegacion = delegacion;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "CodigoPostal{" + "id=" + id + ", codigo=" + codigo + ", colonia=" + colonia + ", delegacion=" + delegacion + ", estado=" + estado + '}';
    }

    
}
