package com.example.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.example.CodigoPostal;
import com.example.Estado;
import java.util.HashSet;

public class CodigoPostalDAO {

    private final Map<String, CodigoPostal> codigos = new HashMap<String, CodigoPostal>();

    public CodigoPostalDAO() {

        codigos.put("04444", new CodigoPostal(4444, "04444", "CTM Culhuacan", "Coyoacan", Estado.CDMX));
        codigos.put("08620", new CodigoPostal(8620, "08620", "Coyuya", "Coyoacan", Estado.CDMX));
        codigos.put("04500", new CodigoPostal(4500, "04500", "Ciudad Universitaria", "Coyoacan", Estado.CDMX));
        codigos.put("03500", new CodigoPostal(3500, "03500", "Napoles", "Benito Juarez", Estado.CDMX));
        codigos.put("09980", new CodigoPostal(9980, "09980", "Lomas de Estrella", "Iztapalapa", Estado.CDMX));
        codigos.put("03810", new CodigoPostal(3810, "03810", "Insurgentes Sur", "Coyoacan", Estado.CDMX));
        codigos.put("03830", new CodigoPostal(3830, "03830", "Insurgentes Centro", "Benito Juarez", Estado.CDMX));
        codigos.put("05830", new CodigoPostal(5830, "05830", "Insurgentes Norte", "Azcapozalco", Estado.CDMX));
    }

    public Collection<CodigoPostal> selectAll() {
        return codigos.values();
    }

    public CodigoPostal selectCpById(String codigo) {
        return codigos.get(codigo);
    }

    public Collection<CodigoPostal> selectCpByName(String colonia) {
        Collection<CodigoPostal> result = new HashSet<CodigoPostal>();
        
        for(CodigoPostal cp : this.codigos.values()) {
            if(cp.getColonia().toLowerCase().indexOf(colonia.toLowerCase()) > -1) {
                result.add(cp);
            }
        }
        return result;
    }
}
