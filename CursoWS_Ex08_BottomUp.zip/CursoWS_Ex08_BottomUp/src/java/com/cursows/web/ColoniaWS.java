/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.cursows.web;

import com.example.CodigoPostal;

/**
 * WS Course
 * @author JLIL
 */
public interface ColoniaWS {

    CodigoPostal buscarCodigoPostal(String id);
    
}
