package com.cursows.web;

import javax.xml.ws.Endpoint;

/**
 * WS Course
 * @author JLIL
 */
public class ColoniaWS01Publisher {
    public static void main(String[] args) {
	   Endpoint.publish("http://localhost:9999/ws/ColoniaWS01", new ColoniaWS01());
    }
}
