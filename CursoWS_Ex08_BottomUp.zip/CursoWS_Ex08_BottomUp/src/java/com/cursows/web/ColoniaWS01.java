package com.cursows.web;

import com.example.CodigoPostal;
import com.example.service.CodigoPostalService;
import com.example.service.CodigoPostalServiceImpl;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

/**
 * WS Course
 * @author JLIL
 */
//@WebService
@WebService(serviceName = "ColoniaService_V01")
//@WebService(endpointInterface = "com.cursows.web.ColoniaWS")
//@SOAPBinding(style = SOAPBinding.Style.RPC)
public class ColoniaWS01 implements ColoniaWS {
    private CodigoPostalService cps = new CodigoPostalServiceImpl();
    
    public ColoniaWS01() {
        System.out.println("Creating instance..." + this);
    }
    
    @Override
    public CodigoPostal buscarCodigoPostal(String id) {
        return cps.consultarCodigoPostalPorCodigo(id);
    } 
    
    @PostConstruct
    private void inicializacion() {
        System.out.println("Inicializando WS " + this);
    }
    
    @PreDestroy
    private void finalizacion() {
        System.out.println("Liberando recursos del WS " + this);
    }
}
