package com.cursows.web;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

@Path("/hello")
public class HelloWorldService {

    @GET
    @Path("/{param}")
    public Response getMsg(@PathParam("param") String msg) {
        String output = "Jersey say : " + msg;
        return Response.status(200).entity(output).build();

    }
    
    @GET
    @Path("/abrazo/{param1}/{param2}")
    public Response getMsg2(@PathParam("param1") String p1, @PathParam("param2") String p2) {
        String output = p1 + " saluda " + p2;
        return Response.status(200).entity(output).build();

    }
}
