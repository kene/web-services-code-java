package com.cursows.web;

import com.example.CodigoPostal;
import com.example.service.CodigoPostalService;
import com.example.service.CodigoPostalServiceImpl;
import java.util.Collection;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("codigospostales")
public class CodigoPostalRsWS {
    private CodigoPostalService cps = new CodigoPostalServiceImpl();
    
    @GET
    @Produces("text/html")
    public Response getAll() {
        StringBuffer sb = new StringBuffer();
        Collection<CodigoPostal> results = this.cps.consultarCodigosPostales();

        sb.append("<body>");
        for(CodigoPostal cp : results) {
            sb.append(cp).append("<br/>");
        }
        sb.append("</body>");
                
        return Response.status(200).entity(sb.toString()).build();
    }
}
